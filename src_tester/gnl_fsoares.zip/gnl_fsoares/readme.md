# run make for all
``` bash
make
```

# run strict mode
```bash
make EXEC_STRICT=1
```
> your are definign the macro so it will define inside